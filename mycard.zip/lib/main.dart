import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: FirstRoute(),
  ));
}

class FirstRoute extends StatelessWidget {
  const FirstRoute({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.teal.shade200,
        title: Center(
          child: Text('정보'),
        ),
      ),
      backgroundColor: Colors.teal,
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const CircleAvatar(
              radius: 50.0,
              backgroundImage: AssetImage('images/mypic.jpg'),
            ),
            const Text(
              '최범규',
              style: TextStyle(
                fontFamily: 'NanumSquareEB',
                fontSize: 30.0,
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
            const Text(
              '성균관대학교 데이터사이언스융합전공',
              style: TextStyle(
                fontFamily: 'NanumSquareL',
                fontSize: 15.0,
                color: Colors.white60,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(
              height: 20.0,
            ),
            Card(
              margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 25.0),
              child: ListTile(
                leading: const Icon(
                  Icons.phone,
                  color: Colors.teal,
                ),
                title: Text(
                  '010-3166-1584',
                  style: TextStyle(
                    color: Colors.teal.shade900,
                    fontFamily: 'NanumSquareEB',
                    fontSize: 20.0,
                  ),
                ),
              ),
            ),
            Card(
              margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 25.0),
              child: ListTile(
                leading: const Icon(
                  Icons.mail,
                  color: Colors.teal,
                ),
                title: Text(
                  'gaenari00@naver.com',
                  style: TextStyle(
                    color: Colors.teal.shade900,
                    fontFamily: 'NanumSquareEB',
                    fontSize: 20.0,
                  ),
                ),
              ),
            ),
            Card(
              margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 25.0),
              child: ListTile(
                leading: const Icon(
                  Icons.account_circle,
                  color: Colors.teal,
                ),
                title: Text(
                  '깃허브: https://github.com/BumKyou',
                  style: TextStyle(
                    color: Colors.teal.shade900,
                    fontFamily: 'NanumSquareEB',
                    fontSize: 15.0,
                  ),
                ),
              ),
            ),
            RaisedButton(
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => PageView1()));
              },
              child: Text('이력'),
            ),
          ],
        ),
      ),
    );
  }
}


class PageView1 extends StatelessWidget {
  const PageView1({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.teal.shade200,
        title: Center(child: Text('이력')),
      ),
      backgroundColor: Colors.teal,
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Card(
              margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 25.0),
              child: ListTile(
                leading: const Icon(
                  Icons.book,
                  color: Colors.teal,
                ),
                title: Text(
                  '21.08 ~ 22.06 \n교내 데이터분석 학회 DScover 활동',
                  style: TextStyle(
                    color: Colors.teal.shade900,
                    fontFamily: 'NanumSquareEB',
                    fontSize: 15.0,
                  ),
                ),
              ),
            ),
            Card(
              margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 25.0),
              child: ListTile(
                leading: const Icon(
                  Icons.groups,
                  color: Colors.teal,
                ),
                title: Text(
                  '22.01 ~ 22.06 DScover 학회장',
                  style: TextStyle(
                    color: Colors.teal.shade900,
                    fontFamily: 'NanumSquareEB',
                    fontSize: 15.0,
                  ),
                ),
              ),
            ),
            Card(
              margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 25.0),
              child: ListTile(
                leading: const Icon(
                  Icons.computer,
                  color: Colors.teal,
                ),
                title: Text(
                  'Python 활용 데이터분석 경험 다수',
                  style: TextStyle(
                    color: Colors.teal.shade900,
                    fontFamily: 'NanumSquareEB',
                    fontSize: 15.0,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
